package com.johnchang.service.demo;

import java.util.List;

public interface GenericWelcomeService {
	public List<String> getWelcomeMessage(String name);
}
